from pathlib import Path
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


def extract_float(string):
    """
    Given an input string such as 'iteration: 10'. Filters the string to return only the number. E.g. Returns 10.
    """
    return float(string.split(' ')[-1])


# Relative path. The learning stats folder should contain 'learning_stats.csv'
path = Path(r"../plot_loss/learning_stats")
files = path.glob('*')
for file in files:
    df = pd.read_csv(file, header=None)
    iterations = df[0].apply(extract_float)
    losses = df[1].apply(extract_float)

    x = np.array(iterations, dtype='float')
    y = np.array(losses, dtype='float')

    # Remove first 5 values otherwise the graph scale is too large.
    # Learning rate rapidly lowers at first anyway.
    x = x[5:]
    y = y[5:]

    # Produce a line of best fit.
    # A 10 fit polynomial is very close fitting but produces a nice visualization.
    polyfit = np.polyfit(x, y, 10)
    polynomial_equation = np.poly1d(polyfit)

    y_pred = polynomial_equation(x)

    # Create the plot and show it.
    plt.scatter(x, y, s=1)
    plt.plot(x, y_pred, color='red')
    plt.xlabel("Iteration")
    plt.ylabel("Loss")
    plt.show()
